import view.FormImovel;


public class Main {
    public static void main(String[] args) {
        FormImovel f = new FormImovel();
        f.setVisible(true);
    }
         
}
